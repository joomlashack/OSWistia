<?php include 'header_default.php'; ?>
<h3>Thanks for update!</h3>
<div>Version: <?php echo $this->manifest->version; ?></div>
