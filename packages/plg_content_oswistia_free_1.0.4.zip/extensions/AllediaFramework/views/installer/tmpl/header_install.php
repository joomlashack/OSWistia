<?php include 'header_default.php'; ?>
<h3>Thanks for install!</h3>
<div>Version: <?php echo $this->manifest->version; ?></div>
