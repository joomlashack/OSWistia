<?php
/**
 * @package   OSCARootCertificates
 * @contact   www.ostraining.com, support@ostraining.com
 * @copyright 2013-2014 Open Source Training, LLC. All rights reserved
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
 */

require_once 'library/installer/include.php';


defined('_JEXEC') or die();

class PlgSystemOSCARootCertificatesInstallerScript extends AllediaInstallerAbstract
{
}
